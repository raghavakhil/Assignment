/// <reference path="mobile.ts" />
namespace Mobile{
    export class BasicPhone extends Mobile{
        mobileType:string;
        printMobileDetails(){
            console.log(this.mobileId,this.mobileName,this.mobileCost,this.mobileType);
        }
    }
}