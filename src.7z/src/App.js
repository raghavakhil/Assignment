import React, { Component } from 'react';

import Projects from './Comp/pro';

import AddProject from './Comp/addProject'
import uuid from 'uuid';
import $ from 'jquery'
import Todos from './Comp/Todos';
class App extends Component {


  constructor(){
    super();
    this.state={
      projects:[]
    }}

componentDidMount(){
       this.getTodos();
}
      getTodos()
      {
           $.ajax({
      url: 'https://jsonplaceholder.typicode.com/todos',
      crossDomain:true,
      type:'GET',
      dataType: 'jsonp',
      cache: false,
      success: function (data) {
        this.setState({ todos: data }, function () {
          console.log(this.state);
        });
      }.bind(this),
      error: function (xhr, status, err) {
        console.log(err);
      }
    });
      }
      
        componentWillMount(){
          console.log("componentWillMount executed");
          this.setState({
            
projects:[
  {
             id:uuid.v4(),
          title:'Magazine',
          category:'Harry Potter and the Half Blood Prince',
          Details:[{
            Duration:'52 minutes',
            Budget:1212234
          },
          {
             Duration:'15 minutes',
            Budget:67868
          
        }]},
        {
          title:'Magazine2',
          category:'Harry Potter and the Deathly Hallows',
          Details:[{
            Duration:'52 minutes',
            Budget:120000
          },
          {
            Duration:'22 minutes',
            Budget:54321
          }]
        }
      ]
    })
        }

handleDeleteProject(id)
{
    let proDel=this.state.projects;
    let index=proDel.findIndex(obj=>obj.id===id)
    proDel.splice(index,1);
    this.setState({projects:proDel});
}


  
        
handleAddProject(newProject)
{
  let proj=this.state.projects;
  proj.push(newProject);
  console.log(newProject);
  this.setState({projects:proj})
}



  render() {
    return (
      <div className="beck">
     <AddProject addProject={this.handleAddProject.bind(this)}/>
     <Projects  onDelete={this.handleDeleteProject.bind(this)} projects={this.state.projects} test="Hii"/>
     <hr/>
     <Todos todos={this.state.todos}/>
      </div>
    );
  }
}
export default App
