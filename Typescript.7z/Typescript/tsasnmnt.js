var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Mobile;
(function (Mobile_1) {
    var Mobile = /** @class */ (function () {
        function Mobile() {
        }
        Mobile.prototype.printMobileDetails = function () {
            console.log(this.mobileId, this.mobileName, this.mobileCost);
        };
        return Mobile;
    }());
    Mobile_1.Mobile = Mobile;
})(Mobile || (Mobile = {}));
/// <reference path="mobile.ts" />
var Mobile;
(function (Mobile) {
    var BasicPhone = /** @class */ (function (_super) {
        __extends(BasicPhone, _super);
        function BasicPhone() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        BasicPhone.prototype.printMobileDetails = function () {
            console.log(this.mobileId, this.mobileName, this.mobileCost, this.mobileType);
        };
        return BasicPhone;
    }(Mobile.Mobile));
    Mobile.BasicPhone = BasicPhone;
})(Mobile || (Mobile = {}));
/// <reference path ="mobile.ts" />
var Mobile;
(function (Mobile) {
    var SmartDetails = /** @class */ (function (_super) {
        __extends(SmartDetails, _super);
        function SmartDetails() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        SmartDetails.prototype.printMobileDetails = function () {
            console.log(this.mobileId, this.mobileName, this.mobileCost, this.mobileType);
        };
        return SmartDetails;
    }(Mobile.Mobile));
    Mobile.SmartDetails = SmartDetails;
})(Mobile || (Mobile = {}));
/// <reference path = "mobile.ts" />
/// <reference path = "basic.ts" />
/// <reference path = "smart.ts" />
var data = [
    {
        "mobileId": 1,
        "mobileName": "Honor 7A",
        "mobileCost": 10000,
        "mobileType": "Android"
    },
    {
        "mobileId": 2,
        "mobileName": "One Plus 6",
        "mobileCost": 540000,
        "mobileType": "Android"
    }
];
function PrintDetails(phone) {
    phone.printMobileDetails();
}
var basic = new Mobile.BasicPhone();
basic.mobileId = data[1].mobileId;
basic.mobileName = data[1].mobileName;
basic.mobileCost = data[1].mobileCost;
basic.mobileType = data[1].mobileType;
PrintDetails(basic);
var smart = new Mobile.SmartDetails();
smart.mobileId = data[0].mobileId;
smart.mobileName = data[0].mobileName;
smart.mobileCost = data[0].mobileCost;
smart.mobileType = data[0].mobileType;
PrintDetails(smart);
